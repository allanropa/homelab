# OpenCode Project Guides

A reusable set of repository instructions for OpenCode, focused on
Python backend services and React frontends.

## Contents

-   `AGENTS.md`: repository-wide instructions OpenCode can use as its
    coding guide.
-   `guides/python.md`: Python conventions and backend design.
-   `guides/react.md`: React component design, file size, TypeScript,
    and frontend architecture.
-   `guides/testing.md`: testing expectations across the stack.
-   `guides/security.md`: security checklist for common application
    work.

## How to use

1.  Copy `AGENTS.md` into the root of a project repository.
2.  Copy the `guides/` directory into that repository.
3.  Keep the instructions aligned with the project's actual stack,
    commands, and conventions.
4.  If a subdirectory needs different rules, add a more specific
    `AGENTS.md` there.

OpenCode can use `AGENTS.md` as repository guidance. These files are
recommendations, not a substitute for inspecting the codebase or
following project-specific instructions.

## Defaults

The guidance is backend-first: Python services should keep domain logic
independent from HTTP and persistence layers; React should favor small
components, explicit state, accessible UI, and focused files. FastAPI
and TypeScript are suggested defaults only when appropriate to the
existing project.
